Author: Yogesh singh
Author URL: https://makitweb.com/
Author Email: makitweb@gmail.com
Tutorial Link: https://makitweb.com/datatables-ajax-pagination-with-search-and-sort-php/

Instructions - 
1. Import employee.sql table in your MySQL database.
2. Update config.php file.

